# Tríade Construtora - Arquivos do Projeto

## Estrutura de Pastas

```
triade-construtora-export/
├── index.html              # Arquivo HTML principal
├── favicon.png             # Ícone do site
├── css/
│   └── style.css          # Estilos CSS compilados
├── js/
│   └── app.js             # JavaScript compilado
├── images/                # Imagens do projeto
├── assets/                # Arquivos de recursos compilados
└── README.md              # Este arquivo
```

## Como Usar

1. **Fazer Upload para Servidor Web:**
   - Copie todos os arquivos para o seu servidor web (Apache, Nginx, etc.)
   - Certifique-se de que o `index.html` está na raiz do diretório público

2. **Estrutura de Arquivos:**
   - `index.html` - Página principal (contém toda a estrutura HTML)
   - `css/style.css` - Todos os estilos compilados
   - `js/app.js` - Todo o JavaScript compilado
   - `images/` - Imagens estáticas do projeto
   - `assets/` - Recursos adicionais

3. **Configuração de Servidor:**
   - Configure seu servidor para servir `index.html` como página padrão
   - Certifique-se de que os caminhos relativos estão corretos

## Informações do Projeto

- **Nome:** Tríade Construtora
- **Tipo:** Website Corporativo
- **Tecnologia:** React + Tailwind CSS
- **Responsividade:** Mobile, Tablet e Desktop

## Contato

- Email: contato@triadeconstrutorabr.com
- Telefone: (71) 99999-9999
- Localização: Salvador, Bahia - Brasil
